-- made by gomi pasted from my old resolver for skeet and hitlogs (fatal and nl)
-- improved by GayBottle 


local angles = {
   [1] = math.random(-10,10),
    [2] = math.random(-20,20),
    [3] = math.random(-30,30),
    [5] = math.random(-40,40),
    [6] = math.random(-50,50),
    [7] = math.random(-60,60),
    [8] = math.random(-70,70),
    [9] = math.random(-80,80),
    [10] = math.random(-90,90),
    [11] = math.random(-100,100),
    [12] = math.random(-110,110),
    [13] = math.random(-120,120),
    [14] = math.random(-130,130),
    [15] = math.random(-140,140),
    [16] = math.random(-150,150),
    [17] = math.random(-160,160),
    [18] = math.random(-170,170),
    [19] = math.random(-180,180),
	[20] = math.random(-190,190),
	[21] = math.random(-200,200),
	[22] = math.random(-200,200),
	[23] = math.random(-200,200),
	[24] = math.random(-210,210),
	[25] = math.random(-220,220),
	[26] = math.random(-230,230),
	[27] = math.random(-240,240),
	[28] = math.random(-250,250),
	[29] = math.random(-260,260),
	[30] = math.random(-270,270),
    [31] = math.random(-280,280),
	[33] = math.random(-290,260),
	[34] = math.random(-300,300),
	[35] = math.random(-310,310),
	[36] = math.random(-320,320),
	[37] = math.random(-330,330),
	[38] = math.random(-340,340),
	[39] = math.random(-350,350),
	[40] = math.random(-360,360),
	[41] = math.random(-0,0),
	[42] = math.random(-10,10),
	[43] = math.random(-20,20),
	[44] = math.random(-30,30),
	[45] = math.random(-40,40),
	[46] = math.random(-50,50),
	[47] = math.random(-60,60),
	[48] = math.random(-70,70),
	[49] = math.random(-80,80),
	[50] = math.random(-90,90),
	[51] = math.random(-100,100),
	[52] = math.random(-110,110),
	[53] = math.random(-120,120),
	[54] = math.random(-130,130),
	[55] = math.random(-140,140),
	[56] = math.random(-150,150),
	[57] = math.random(-150,160),
	[58] = math.random(-170,170),
	[59] = math.random(-180,180),
	[60] = math.random(-190,190),
	[61] = math.random(-200,200),
	[62] = math.random(-210,210),
	[63] = math.random(-220,220),
	[64] = math.random(-230,230),
	[65] = math.random(-240,240),
	[66] = math.random(-250,250),
	[67] = math.random(-260,260),
	[68] = math.random(-270,270),
	[69] = math.random(-280,280),
	[70] = math.random(-290,290),
	[71] = math.random(-300,300),
	[72] = math.random(-310,310),
	[73] = math.random(-320,320),
	[74] = math.random(-330,330),
	[75] = math.random(-340,340),
	[76] = math.random(-350,350),
	[77] = math.random(-360,360),
}

local last_angle =77
local new_angle = math.random(1,77)
local switch1 = true
local switch2 = false
local i = 77


menu.add_check_box("Enable Resolver lua")





-- note from gomi, fix the last angle check bullshit for logs instead of it just saying it missed at 0...


local function resolve(shot_info)
	local result = shot_info.result
	local gpinf = engine.get_player_info
	local target = shot_info.target_index
	local target_name = gpinf(target).name
   
    
    menu.set_bool("player_list.player_settings[" .. target.. "].force_body_yaw", true) -- we only want to bruteforce our target. not everyone
    
    if last_angle == -new_angle and switch1 then
        new_angle = -angles[i]
        if switch2 == true then
            switch1 = not switch1
        end
    else
        if i < #angles then
            i = i + 77
        else
            i = 1
        end
        new_angle = angles[i]
    end
    if last_angle == 0 then
        last_angle = "LW RESOLVER"
    end


	if result == "Resolver" and menu.get_bool("Enable Resolver lua") then
	print("[DEBUG] missed player: " ..target_name .. ", at angle: " .. last_angle .. ", bruteforced to: " .. new_angle) -- last_angle is broken and always says "0"
    
	menu.set_int("player_list.player_settings["..target.."].body_yaw", new_angle) -- so we dont have to do a for check
    end

    if result == "Hit" and menu.get_bool("Enable Resolver lua") then
        print("[DEBUG] hit player " ..target_name.. ", at angle: " .. new_angle)
    end
end

client.add_callback("on_shot", resolve)




