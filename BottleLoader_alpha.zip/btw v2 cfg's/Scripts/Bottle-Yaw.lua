--lua made by GayBottle
--for Bottleware Alpha

client.log("Loading BottleYaw...")
client.log("hello user")
client.log("Developed by GayBottle")

menu.add_combo_box("CREDITS:", { "BottleYaw", "VER:1.5", "UPD: 26.02.2023" })
menu.add_combo_box("FIRST TAB:", { "[1] Chat:" })


menu.add_check_box("Killsay")

local randomNo
local killtext

function killsay(event)
    if menu.get_bool("Killsay") then
    local attacker = engine.get_player_for_user_id(event:get_int("attacker"))
    local dead = engine.get_player_for_user_id(event:get_int("userid"))
    local me = engine.get_local_player_index()
        
        if attacker == me and dead ~= me then
        killtext = {"omg, you own by bottleware aka lw paste cheat",
        "1eznndog, please quit hvh",
        "BottleYaw the best lua, play or die"}
        randomNo = math.random (1,3)
        console.execute ("say " .. killtext[randomNo])
        end
    end
end

events.register_event("player_death", killsay)


menu.add_check_box("Chatspam")
local phrases = { "BottleYaw - use or die", "BottleYaw - get the best free cheat, Bottleware", "BottleYaw - ez own other free cheat", "BottleYaw - own by GayBottle", "BottleYaw - ew win, why so EZ? because you dont use BottleWare" }
local nextuse = 0
local idx = 1

local function on_paint()
    
    if globals.get_curtime() > nextuse then
        if menu.get_bool("Chatspam") then
        console.execute("say \"" .. phrases[idx % #phrases + 1] .. "\"")
        idx = idx + 1
        nextuse = globals.get_curtime() + 1
    end
    end
end
client.add_callback("on_paint", on_paint)


menu.add_check_box("Aimware Chatspam")
local phrases = { "www.AIMWARE.NET | Premium Rage CSGO Cheat", "www.AIMWARE.NET | Premium Legit CSGO Cheat", "www.AIMWARE.NET | Premium CSGO Cheat", "www.AIMWARE.NET | Premium Software For CSGO" }
local nextuse = 0
local idx = 1

local function on_paint()
    
    if globals.get_curtime() > nextuse then
        if menu.get_bool("Aimware Chatspam") then
        console.execute("say \"" .. phrases[idx % #phrases + 1] .. "\"")
        idx = idx + 1
        nextuse = globals.get_curtime() + 1
    end
    end
end
client.add_callback("on_paint", on_paint)


menu.add_check_box("Neverlose Chatspam")

local phrases = { "neverlose.cc - buy or die", "neverlose.cc - just the best", "neverlose.cc - better than luck", "neverlose.cc - dont be owned anymore" }
local nextuse = 0
local idx = 1

local function on_paint()

    if menu.get_bool("Neverlose Chatspam") then

        if globals.get_curtime() > nextuse then
            console.execute("say \"" .. phrases[idx % #phrases + 1] .. "\"")
            idx = idx + 1
            nextuse = globals.get_curtime() + 1
        end
	end
end
client.add_callback("on_paint", on_paint)


menu.add_check_box("Nixware Chatspam")

local phrases = { "nixware.cc - buy or die", "nixware.cc - just the best", "nixware.cc - better than luck", "nixware.cc - dont be owned anymore" }
local nextuse = 0
local idx = 1

local function on_paint()

    if menu.get_bool("Nixware Chatspam") then

        if globals.get_curtime() > nextuse then
            console.execute("say \"" .. phrases[idx % #phrases + 1] .. "\"")
            idx = idx + 1
            nextuse = globals.get_curtime() + 1
        end
	end
end
client.add_callback("on_paint", on_paint)


menu.add_combo_box("SECOND TAB:", { "[2] Visual/Misc:" })

menu.add_check_box("Force Croshair")

local function ForceCrosshair()

    if menu.get_bool("Force Croshair") then

        local local_player = entitylist.get_local_player()
        local is_scoped = local_player:is_scoped()

        console.set_string("weapon_debug_spread_show", "3")

        if is_scoped == true then

            console.set_string("weapon_debug_spread_show", "0")

        else

            console.set_string("weapon_debug_spread_show", "3")

        end

    else

        console.set_string("weapon_debug_spread_show", "0")

    end
end


client.add_callback("on_paint", ForceCrosshair)


menu.add_check_box("Better Scope")

local function wievinsocpe()
    if menu.get_bool( "Better Scope" ) then
        console.set_int("fov_cs_debug", 90)
    else
        console.set_int("fov_cs_debug", 0)
    end
end

client.add_callback( "on_paint" , wievinsocpe)


menu.add_check_box("Radgol Physics")

local function Ragdoll_Physics()

    if menu.get_bool("Radgol Physics") then
    
    console.set_string("cl_ragdoll_physics_enable", "0")

    else

    console.set_string("cl_ragdoll_physics_enable", "1")

    end
end

client.add_callback("on_paint", Ragdoll_Physics)


menu.add_check_box("More Fps")

local function FpsBoost()

    if menu.get_bool("More Fps") then
        
        console.set_string("r_shadows", "0")
        console.set_string("cl_csm_static_prop_shadows", "0")
        console.set_string("cl_csm_shadows", "0")
        console.set_string("cl_csm_world_shadows", "0")
        console.set_string("cl_foot_contact_shadows", "0")
        console.set_string("cl_csm_viewmodel_shadows", "0")
        console.set_string("cl_csm_rope_shadows", "0")
        console.set_string("cl_csm_sprite_shadows", "0")

        console.set_string("violence_hblood", "0")

        console.set_string("r_3dsky", "0")

        console.set_string("r_drawdecals", "0")

        console.set_string("r_drawrain", "0")

        console.set_string("r_drawropes", "0")

        console.set_string("r_drawsprites", "0")

        console.set_string("fog_enable_water_fog", "0")

        console.set_string("cl_showhelp", "0")
        console.set_string("cl_autohelp", "0")
        console.set_string("cl_disablehtmlmotd", "1")
        console.set_string("cl_disablefreezecam", "1")

    else

        console.set_string("r_shadows", "1")
        console.set_string("cl_csm_static_prop_shadows", "1")
        console.set_string("cl_csm_shadows", "1")
        console.set_string("cl_csm_world_shadows", "1")
        console.set_string("cl_foot_contact_shadows", "1")
        console.set_string("cl_csm_viewmodel_shadows", "1")
        console.set_string("cl_csm_rope_shadows", "1")
        console.set_string("cl_csm_sprite_shadows", "1")
        
        console.set_string("violence_hblood", "1")
        
        console.set_string("r_3dsky", "1")
        
        console.set_string("r_drawdecals", "1")
        
        console.set_string("r_drawrain", "1")
        
        console.set_string("r_drawropes", "1")
        
        console.set_string("r_drawsprites", "1")
        
        console.set_string("fog_enable_water_fog", "1")
        
        console.set_string("cl_showhelp", "1")
        console.set_string("cl_autohelp", "1")
        console.set_string("cl_disablehtmlmotd", "0")
        console.set_string("cl_disablefreezecam", "0")
    end
end

client.add_callback("on_paint", FpsBoost)


menu.add_check_box("Left Hand")

local function Ragdoll_Physics()

    if menu.get_bool("Left Hand") then
    
    console.set_string("cl_righthand", "0")

    else

    console.set_string("cl_righthand", "1")
    end
end

client.add_callback("on_paint", Ragdoll_Physics)




menu.add_combo_box( "Skybox List", { "Not Selected", "Italy", "Daylight", "Cloudt", "Night", "Night flat", "Blue", "Embasst", "Aztec", "Office", "Vietnam", "Lunacy", "Tibet" } )

local function skybox()

    if menu.get_int( "Skybox List" ) == 0 then
        console.set_string( "sv_skyname", "sky125" )
      
    elseif menu.get_int( "Skybox List" ) == 1 then
        console.set_string( "sv_skyname", "italy" )
      
    elseif menu.get_int( "Skybox List" ) == 2 then
        console.set_string( "sv_skyname", "sky_cs15_daylight01_hdr" )

    elseif menu.get_int( "Skybox List" ) == 3 then
        console.set_string( "sv_skyname", "sky_csgo_cloudy01" )

    elseif menu.get_int( "Skybox List" ) == 4 then
        console.set_string( "sv_skyname", "sky_csgo_night02" )

    elseif menu.get_int( "Skybox List" ) == 5 then
        console.set_string( "sv_skyname", "sky_csgo_night_flat" )
  
    elseif menu.get_int( "Skybox List" ) == 6 then
        console.set_string( "sv_skyname", "nukeblank" )

    elseif menu.get_int( "Skybox List" ) == 7 then
        console.set_string( "sv_skyname", "embassy" )

    elseif menu.get_int( "Skybox List" ) == 8 then
        console.set_string( "sv_skyname", "sky_hr_aztec" )

    elseif menu.get_int( "Skybox List" ) == 9 then
        console.set_string( "sv_skyname", "office" )

    elseif menu.get_int( "Skybox List" ) == 10 then
        console.set_string( "sv_skyname", "vietnam" )

    elseif menu.get_int( "Skybox List" ) == 11 then
        console.set_string( "sv_skyname", "sky_lunacy" )

    elseif menu.get_int( "Skybox List" ) == 12 then
        console.set_string( "sv_skyname", "cs_tibet" )
  
    end

end

client.add_callback("on_paint", skybox)


menu.add_combo_box("Hand List", { "Not Selected", "Black", "Brown", "Asian", "Red", "Tattoo" })

local function HandChanger()

    if menu.get_int("Hand List") == 0 then
        console.set_int("r_skin", 0)

    elseif menu.get_int("Hand List") == 1 then
        console.set_int("r_skin", 1)

    elseif menu.get_int("Hand List") == 2 then
        console.set_int("r_skin", 2)

    elseif menu.get_int("Hand List") == 3 then
        console.set_int("r_skin", 3)

    elseif menu.get_int("Hand List") == 4 then
        console.set_int("r_skin", 4)

    elseif menu.get_int("Hand List") == 5 then
        console.set_int("r_skin", 5)

    end

end

client.add_callback("on_paint", HandChanger)


local lpsopg = "lpsopg.wav"
local sound_path = "hitsounds/"

local function play_hitsound(sound_name)
    console.execute("playvol " .. sound_name .. " 1")
end

local function smthn(shot_info) 
 
    local result = shot_info.result

    if result == "Hit" then
            play_hitsound(lpsopg)
        end
    end

client.add_callback("on_shot", smthn)


menu.set_bool("Misc.show_default_log", true)

local function Logs(shot_info)

	local enemy = entitylist.get_player_by_index(i)
	local local_player = entitylist.get_local_player()
	local name = shot_info.target_name
	local server_hitbox = shot_info.server_hitbox
	local client_hitbox = shot_info.client_hitbox
	local server_damage = shot_info.server_damage
	local client_damage = shot_info.client_damage
	local backtrack = shot_info.backtrack_ticks
	local hitchance = shot_info.hitchance
	local result = shot_info.result
	local safe = shot_info.safe

	if result == "Hit" then

		client.log("[+] SHOT INFO - NAME: " .. name .. " | HITBOX: " .. client_hitbox .. " | DAMAGE: "  .. client_damage .. "")

	elseif result == "Spread" then

		client.log("[-] YOU MISSED AGAIN | REASON: IQLESS+YOU R GAY")

	elseif result == "Resolver" then

		client.log("[-] YOU MISSED AGAIN | REASON: CFG ISSUE xDD")
		
	end	
end

local function BombBeginPlant(event)

	client.log("[-] BottleYaw - IDIOTS PLANTING BOMB")

end

local function BombPlant(event)

	client.log("[-] BottleYaw - BOMB PLANTED BY IDIOTS")

end

local function BombBeginDefuse(event)

	client.log("[-] BottleYaw - BOBM DEFUSED BY NIGGAR")

end

local function HostageTaken(event)

	client.log("[-] LEXOF.LUA - HOSTAGE TAKED, MOTHERFUCKA")

end

client.add_callback("on_shot", Logs)

events.register_event("bomb_planted", BombPlant)
events.register_event("bomb_beginplant", BombBeginPlant)
events.register_event("bomb_begindefuse", BombBeginDefuse)
events.register_event("hostage_follows", HostageTaken)


menu.add_check_box("Rainbow Line")
menu.add_slider_int("Line Width", 1, 4)
menu.add_check_box("Line on Top")
menu.add_check_box("Line on Left")
menu.add_check_box("Line on Down")
menu.add_check_box("Line on Right")

local function paint()
    if menu.get_bool("Rainbow Line") then   
        local screen_width = engine.get_screen_width()
        local screen_height = engine.get_screen_height()
        local LineWidth = menu.get_int("Line Width")
        local r = math.floor(math.sin(globals.get_realtime() * 2) * 127 + 128)
        local g =  math.floor(math.sin(globals.get_realtime() * 2 + 2) * 127 + 128)
        local b = math.floor(math.sin(globals.get_realtime() * 2 + 4) * 127 + 128)

        local startXOffset, startYOffset, WidthOffset, HeightOffset = 0, 0, 0, 0
        if menu.get_bool("Line on Left") then
            startXOffset = startXOffset + LineWidth
            WidthOffset = WidthOffset - LineWidth
        end
        if menu.get_bool("Line on Right") then
            WidthOffset = WidthOffset - LineWidth
        end


        if menu.get_bool("Line on Top") then
             render.draw_rect_filled(startXOffset, 0, screen_width + WidthOffset, LineWidth, color.new(r, g, b, 160))
        end

        if menu.get_bool("Line on Down") then
             render.draw_rect_filled(startXOffset, screen_height - LineWidth, screen_width + WidthOffset, LineWidth, color.new(r, g, b, 160))
        end

        if menu.get_bool("Line on Left") then
            render.draw_rect_filled(0, 0, LineWidth, screen_height, color.new(r, g, b, 160))
        end

        if menu.get_bool("Line on Right") then
            render.draw_rect_filled(screen_width - LineWidth, 0, LineWidth, screen_height, color.new(r, g, b, 160))
        end
    end
end

client.add_callback("on_paint", paint)


menu.add_combo_box("THIRD TAB:", { "[3] Indicators:" })

local font = render.create_font("MuseoSansCyrl-500", 13, 500, true, false, false)
local font1 = render.create_font("MuseoSansCyrl-600", 15, 600, true, false, false)
menu.add_check_box("Watermark")
client.add_callback("on_paint", function()
    if menu.get_bool("Watermark") then
        local screen_width = engine.get_screen_width()
        local username = globals.get_username()
        local ping = tostring(globals.get_ping())
        local ip = globals.get_server_address()
        local tickrate = math.floor(1.0 / globals.get_intervalpertick())
        local wm
        if engine.is_connected() then
            wm1 = tostring(" Bottle-Yaw ")
            wm2 = tostring(" Bottle-Yaw  ")
            wm =  tostring("                          |  version 1.5  |  " .. ping .. "ms  |  " .. tickrate .. "tick |  ".. ip .. "  " )
        else
            wm1 = tostring(" Bottle-Yaw  ")
            wm2 = tostring(" Bottle-Yaw  ")
            wm =  tostring("                          |  version 1.5  |  0 ms  |  offline  ")
        end
        local width = render.get_text_width(font, wm)
        local background_color = color.new(14, 18, 19, 100)
        local background_color1 = color.new(14, 18, 19, 100)
        local background_color2 = color.new(14, 18, 19, 100)
        local background_color3 = color.new(14, 18, 19, 100)
        local background_color4 = color.new(14, 18, 19, 100)
        local wm_color = color.new(34, 159, 190, 255)
        local wm_color1 = color.new(255, 255, 255, 255)
        local x = screen_width - 10 - width - 4
        local y = 10
        local w = width + 5
        render.draw_rect_filled(x, y + 1, w, 15, background_color)
        render.draw_rect_filled(x, y + 1, w, 15, background_color1)
        render.draw_rect_filled(x, y + 16, w, 1, background_color2)
        render.draw_rect_filled(x, y + 17, w, 1, background_color3)
        render.draw_rect_filled(x, y, w, 1, background_color2)
        render.draw_rect_filled(x, y - 1, w, 1, background_color3)
        render.draw_rect_filled(x, y, w, 1, background_color4)
        render.draw_text(font, x, y + 2, wm_color1, wm)
        render.draw_text(font, x + 6, y + 2, wm_color, wm1)
        render.draw_text(font, x + 5, y + 2, wm_color1, wm2)
    end
end)


local font = render.create_font("Verdana", 16, 500, true, true, false)
menu.add_check_box("Keybinds")
menu.add_slider_int("Keybinds Position X", 0, engine.get_screen_width())
menu.add_slider_int("Keybinds Position Y", 0, engine.get_screen_height())

local types = 
{ 
    " ", 
    " " 
}

local get_state, get_mode = menu.get_key_bind_state, menu.get_key_bind_mode
local screen_x, screen_y = engine.get_screen_width(),engine.get_screen_height()
local count = 0

local function add_bind(name, bind_name, x, y)
    if get_state(bind_name) then
        render.draw_text(font, x + 5, y + 22 + (15 * count), color.new(255, 255, 255), name)     
        text_width = render.get_text_width(font, "[" .. types[get_mode(bind_name) + 1] .. "]")
     
        count = count + 1    
    end
end

local function on_paint()

    if not menu.get_bool("Keybinds") then 
        return 
    end

    if not engine.is_in_game() then 
        return 
    end
  
    local color = menu.get_color("Menu.menu_color")
    local pos_x = menu.get_int("Keybinds Position X")
    local pos_y = menu.get_int("Keybinds Position Y") 
  
    render.draw_rect_filled(pos_x, pos_y, 170, 21, color.new(0, 0, 0, 120)) 
    render.draw_rect_filled(pos_x, pos_y, 170, 22 + (15 * count) + 3, color.new(0, 0, 0, 70)) 
    render.draw_text(font, pos_x + 5, pos_y + 1, color.new(255, 255, 255), "         keybinds") 
    render.draw_rect_filled(pos_x, pos_y + 19, 170, 2, color)
    
    count = 0
  
    add_bind("Double tap", key_binds.double_tap, pos_x, pos_y)
    add_bind("Hide shots", key_binds.hide_shots, pos_x, pos_y)
    add_bind("Force body", key_binds.body_aim, pos_x, pos_y)
    add_bind("Damage override", key_binds.damage_override, pos_x, pos_y)
    add_bind("Invert desync", key_binds.flip_desync, pos_x, pos_y)
    add_bind("Thirdperson", key_binds.thirdperson, pos_x, pos_y)
    add_bind("Automatic peek", key_binds.automatic_peek, pos_x, pos_y)
    add_bind("Fake duck", key_binds.fakeduck, pos_x, pos_y)
    add_bind("Slow walk", key_binds.slowwalk, pos_x, pos_y)
    add_bind("Edge jump", key_binds.edge_jump, pos_x, pos_y)
end

client.add_callback("on_paint", on_paint)


local font =  render.create_font("Verdana", 12, 500, true, true, true)

menu.add_check_box("Desync Arrows")
menu.next_line()
menu.add_color_picker("Desync Model")
menu.add_color_picker("Real Model")

local function draw()
if menu.get_bool("Desync Arrows") then
   
    local Real = menu.get_color("Desync Model")
    local Desync = menu.get_color("Real Model")

    if menu.get_bool("Desync Arrows") then
	
        render.draw_text(font, 931, 530, color.new(0, 0, 0), "<")
        render.draw_text(font, 977, 530, color.new(0, 0, 0), ">")

            if menu.get_key_bind_state(key_binds.flip_desync) then
                render.draw_text(font, 977, 530, color.new(0, 0, 0), ">")
	        else
	            render.draw_text(font, 931, 530, color.new(0, 0, 0), "<")
            end
    end
	
	if menu.get_bool("Desync Arrows") then
	
	    render.draw_text(font, 931, 530, Real, "<")
        render.draw_text(font, 977, 530, Real, ">")

            if menu.get_key_bind_state(key_binds.flip_desync) then
                render.draw_text(font, 977, 530, Desync, ">")
	        else
	            render.draw_text(font, 931, 530, Desync, "<")
            end
    end	
end
end

client.add_callback("on_paint", draw)


local hits, misses_spread, misses_resolver = 0, 0, 0
local font = render.create_font("Arial", 15, 500, true, true, false)

menu.add_check_box("Miss Counter")
menu.add_slider_int("Counter Position X", 0, 1560, engine.get_screen_width())
menu.add_slider_int("Counter Position Y", 0, 1080, engine.get_screen_height())

local function shot(shot_info)
    if shot_info.result == "Hit" then
        hits = hits + 1
    elseif shot_info.result == "Spread" then
        misses_spread = misses_spread + 1
    else
        misses_resolver = misses_resolver + 1
    end
end

local function paint()
    if menu.get_bool("Miss Counter") then
        local x = menu.get_int("Counter Position X")
        local y = menu.get_int("Counter Position Y")

        render.draw_rect_filled(x - 1, y - 1, 352, 7, color.new(16, 22, 29, 160))

        if hits > 0 or misses_spread > 0 or misses_resolver > 0 then
            local fired_shots = hits + misses_spread + misses_resolver
        
            local main_hits_percent = math.floor(hits / fired_shots * 100.0 + 0.5)
            local main_misses_spread_percent = math.floor(misses_spread / fired_shots * 100.0 + 0.5)
            local main_misses_resolver_percent = math.floor(misses_resolver / fired_shots * 100.0 + 0.5)

            local main_percents = main_hits_percent + main_misses_spread_percent + main_misses_resolver_percent

            if main_percents ~= 100 then
                main_hits_percent = main_hits_percent + 100 - main_percents
            end

            local hits_percent = math.floor(hits / (hits + misses_spread + misses_resolver) * 340.0 + 0.5)
            local misses_spread_percent = math.floor(misses_spread / (hits + misses_spread + misses_resolver) * 340.0 + 0.5)
            local misses_resolver_percent = math.floor(misses_resolver / (hits + misses_spread + misses_resolver) * 340.0 + 0.5)

            local percents = hits_percent + misses_spread_percent + misses_resolver_percent

            if percents ~= 340 then
                hits_percent = hits_percent + 340 - percents
            end

            local half_width = math.floor((render.get_text_width(font, "ХАЕС: " .. tostring(hits) .. " (" .. tostring(main_hits_percent) .. "%%)") + 340 - render.get_text_width(font, "ЗАЛУПА ЧИТ: " .. tostring(misses_resolver) .. " (" .. tostring(main_misses_resolver_percent) .. "%%)")) * 0.5 + 0.5)
        
            render.draw_text(font, x, y - 16, color.new(0, 255, 0), "ХАЕС: " .. tostring(hits) .. " (" .. tostring(main_hits_percent) .. "%%)")
            render.draw_text_centered(font, x + half_width, y - 16, color.new(255, 153, 0), true, false, "СПРИДИК: " .. tostring(misses_spread) .. " (" .. tostring(main_misses_spread_percent) .. "%%)")
            render.draw_text(font, x + 340 - render.get_text_width(font, "ЗАЛУПА СОФТ: " .. tostring(misses_resolver) .. " (" .. tostring(main_misses_resolver_percent) .. "%%)"), y - 16, color.new(255, 0, 0), "ЗАЛУПА СОФТ: " .. tostring(misses_resolver) .. " (" .. tostring(main_misses_resolver_percent) .. "%%)")

            render.draw_rect_filled(x, y, hits_percent, 5, color.new(0, 255, 0))
            render.draw_rect_filled(x + hits_percent, y, misses_spread_percent, 5, color.new(255, 153, 0))
            render.draw_rect_filled(x + hits_percent + misses_spread_percent, y, misses_resolver_percent, 5, color.new(255, 0, 0))
        else   
            local half_width = math.floor((render.get_text_width(font, "ХАЕС: 0 (0%%)") + 340 - render.get_text_width(font, "ЗАЛУПА СОФТ: 0 (0%%)")) * 0.5 + 0.5)
        
            render.draw_text(font, x, y - 16, color.new(0, 255, 0), "ХИТАС: 0 (0%%)")
            render.draw_text_centered(font, x + half_width, y - 16, color.new(255, 153, 0), true, false, "СПРИДИК 0 (0%%)")
            render.draw_text(font, x + 340 - render.get_text_width(font, "ЗАЛУПА СОФТ: 0 (0%%)"), y - 16, color.new(255, 0, 0), "ЗАЛУПА СОФТ: 0 (0%%)")
        end
    end
end

client.add_callback("on_shot", shot)
client.add_callback("on_paint", paint)


menu.add_combo_box("FOURTH TAB:", { "[4] Antiaim:" })

menu.add_check_box("Fakelag")
menu.add_check_box("Leg Breaker")


local function randomfakelag()

if menu.get_bool("Fakelag") then     
menu.set_int("Antiaim.fake_lag_type", math.random(1,4))
menu.set_int("Antiaim.fake_lag_limit", math.random(5,16))
end
 end

client.add_callback("on_createmove",randomfakelag)


menu.add_check_box("Unhittable Slowwalk")
local switch = true
local function createmove()
    if menu.get_bool("Unhittable Slowwalk") and cmd.get_send_packet() == true then
        if switch then
            switch = false
        else
            switch = true
        end

        if switch then

           menu.set_int("1Antiaim.desync_range", 38)
           menu.set_int("1Antiaim.inverted_desync_range", 60)
        else
           menu.set_int("1Antiaim.desync_range", 60)
           menu.set_int("1Antiaim.inverted_desync_range", 44)

        end
    end
end
client.add_callback("on_createmove", createmove)


menu.add_check_box("Jitter Range")
menu.add_slider_int("Stand Minimum", 1, 180)
menu.add_slider_int("Stand Maximum", 1, 180)
menu.add_slider_int("Slowwalk Minimum", 1, 180)
menu.add_slider_int("Slowwalk Maximum", 1, 180)

local yaw = true
local function createmove()
    if menu.get_bool("Jitter Range") and cmd.get_send_packet() == true then
		local SS1 = menu.get_int("Stand Minimum")
		local SS2 = menu.get_int("Stand Maximum")
		local SW1 = menu.get_int("Slowwalk Minimum")
		local SW2 = menu.get_int("Slowwalk Maximum")

        if yaw then
            yaw = false
        else
            yaw = true
        end

        if yaw then
        	if menu.get_key_bind_state(key_binds.double_tap) == false and menu.get_key_bind_state(key_binds.hide_shots) == false then
            	menu.set_int("1Antiaim.desync_range", math.random(FWF1, FWF2))
            	menu.set_int("2Antiaim.desync_range", math.random(FFF1, FFF2))
        	else
            	menu.set_int("1Antiaim.desync_range", math.random(SWF1, SWF2))
            	menu.set_int("2Antiaim.desync_range", math.random(SFF1, SFF2))
            end

            menu.set_int("0Antiaim.range", math.random(FS1, FS2))
            menu.set_int("1Antiaim.range", math.random(FW1, FW2))
            menu.set_int("2Antiaim.range", math.random(FF1, FF2))
        else
        	menu.set_int("0Antiaim.range", math.random(SS1, SS2))
        	menu.set_int("1Antiaim.range", math.random(SW1, SW2))
            menu.set_int("2Antiaim.range", math.random(SF1, SF2))
        end
    end
end

local ilean = false
local function createilean()
    if menu.get_bool("Jitter Range") and cmd.get_send_packet() == true then
        if ilean then
            ilean = false
        else
            ilean = true
        end

        if ilean then
            menu.set_int("1Antiaim.inverted_body_lean", math.random(FWL1, FWL2))
            menu.set_int("2Antiaim.inverted_body_lean", math.random(FFL1, FFL2))
            menu.set_int("3Antiaim.inverted_body_lean", math.random(FAL1, FAL2))
        else
            menu.set_int("1Antiaim.inverted_body_lean", math.random(SWL1, SWL2))
            menu.set_int("2Antiaim.inverted_body_lean", math.random(SFL1, SFL2))
            menu.set_int("3Antiaim.inverted_body_lean", math.random(SAL1, SAL2))
        end
    end
end

client.add_callback("on_createmove", createmove)
client.add_callback("on_createmove", createlean)
client.add_callback("on_createmove", createilean)
client.add_callback("on_createmove", createspeed)











