﻿-- created by thoumi#6845/cat1337#1337
-- made by cat1337#1337/thoumi#6845

menu.add_check_box("fakelag switch")
local switch = true

local function createmove()
    if menu.get_bool("fakelag switch") and cmd.get_send_packet() == true then
        if switch then
            switch = false
        else
            switch = true
        end 

        if switch then






menu.set_int("Antiaim.fake_lag_limit", 1)




		  
        else






menu.set_int("Antiaim.fake_lag_limit", 16)





        end
    end
end

client.add_callback("on_createmove", createmove)

menu.add_check_box("Kill Say")

local randomNo
local killtext

function killsay(event)
    if menu.get_bool("Kill Say") then
    local attacker = engine.get_player_for_user_id(event:get_int("attacker"))
    local dead = engine.get_player_for_user_id(event:get_int("userid"))
    local me = engine.get_local_player_index()
        
        if attacker == me and dead ~= me then
        killtext = {"1 owned by catyaw.lua",
            "1 Прикупи catyaw.lua нищий ",
            "Купи Hentaiware.uwu",
            "Owned by cat1337",
            "упал нищий с кряком сраталити.свин",
			"1 , самосвал ебаный",
			"1 клоун с neverlose.cc",
			"Чел чё тя так овнят ",
			"Owned by cat1337",
			"Чел тебя заовнил сам Леонидзе",
            "Owned by cat1337"}
            randomNo = math.random (1,6)
        console.execute ("say " .. killtext[randomNo])
        end
    end
end

events.register_event("player_death", killsay)

-- ui
menu.add_check_box("indicators")
menu.add_check_box("arrows")
menu.next_line()
menu.add_color_picker("Color of active arrows")
menu.add_color_picker("Color of active indicators")


-- font
local font = render.create_font("Segoi UI", 13, 400, true, true, true) -- u can change font of indicators here
local font_arrows = render.create_font("Arial", 30, 600, true, true, false)

-- vars
local screen_x,screen_y = engine.get_screen_width(),engine.get_screen_height()
local get_state, get_mode, s_width = menu.get_key_bind_state, menu.get_key_bind_mode, render.get_text_width
local count = 0
local distance = 12
local red_color = color.new(255,0,0) -- change it and color of inactive indicators be changed

-- main
local function GetColorFromBool(value, first_color, second_color)
    return value and first_color or second_color
end

local function middle(label, bind_name, x, y, color, font)

    local width = render.get_text_width(font, label)
   
    render.draw_text(font, x - (width / 2), y + distance + (12 * count), GetColorFromBool(get_state(bind_name), color, red_color), label)
   
    count = count + 1

end

local function on_paint()
   
    if not menu.get_bool("indicators") then return end
   
    local color_arrows = menu.get_color("Color of active arrows")
    local color_ind = menu.get_color("Color of active indicators")
   
    if menu.get_bool("arrows") then
   
        render.draw_text(font_arrows, screen_x/2 - 45 - (s_width(font_arrows, "<")/2), screen_y/2 - 14, GetColorFromBool(get_state(key_binds.manual_left), color_arrows, color.new(255,255,255)), "<") -- "color.new(255,255,255)" change it and color of inactive arrows be changed
        render.draw_text(font_arrows, screen_x/2 + 45 - (s_width(font_arrows, ">")/2), screen_y/2 - 14, GetColorFromBool(get_state(key_binds.manual_right), color_arrows, color.new(255,255,255)), ">")
        render.draw_text(font_arrows, screen_x/2 - (s_width(font_arrows, "˅")/2), screen_y/2 + 20, GetColorFromBool(get_state(key_binds.manual_back), color_arrows, color.new(255,255,255)), "˅")
   
        distance = 50
   
    else
   
        distance = 12
       
    end
   
    render.draw_text(font, 100, 100, color.new(255, 255, 255), tostring(menu.get_int("Antiaim.lby_type")))
    count = 0
   
    middle("SW", key_binds.slowwalk, screen_x/2, screen_y/2, color_ind, font)
    middle("FB", key_binds.body_aim, screen_x/2, screen_y/2, color_ind, font)
    middle(get_state(key_binds.flip_desync) and "RIGHT" or "LEFT", key_binds.flip_desync, screen_x/2, screen_y/2, red_color, font)
    -- u can add ur bind here
end

-- callbacks
client.add_callback("on_paint", on_paint)

menu.add_check_box("Enable AA")
menu.add_slider_int("Max Delta", 1, 15)
menu.add_slider_int("Static dsync", 1, 100)
menu.add_slider_int("Slowwalk", 1, 100)
menu.add_slider_int("Move", 1, 100)
menu.add_slider_int("Air", 1, 100)
menu.add_check_box("Lag Peek")
local function createnoise()
    if menu.get_bool("Enable AA") and cmd.get_send_packet() == true then
    	local del = menu.get_int("Max Delta")
        local random = math.random(0, 1)
        local cheker = true
        local a1 = menu.get_int("Static dsync")
        local a2 = menu.get_int("Slowwalk")
        local a3 = menu.get_int("Move")
        local a4 = menu.get_int("Air")
        local d1 = math.random(1, del)
        local d2 = math.random(1, del)
        local d3 = math.random(1, del)
        local d4 = math.random(1, del)
        if random == 1 and cheker == true then
            cheker = false
            menu.set_int("0Antiaim.desync_range", a1+d1)
            menu.set_int("1Antiaim.desync_range", a2+d2)
            menu.set_int("2Antiaim.desync_range", a3+d3)--DA
            menu.set_int("3Antiaim.desync_range", a4+d4)
        elseif random == 1 and cheker == true then
        	menu.set_int("0Antiaim.desync_range", a1)
        	menu.set_int("1Antiaim.desync_range", a2)
            menu.set_int("2Antiaim.desync_range", a3)
            menu.set_int("3Antiaim.desync_range", a4)
            cheker = true
        elseif random == 0 and cheker == false then
            menu.set_int("0Antiaim.desync_range", a1-d1)
            menu.set_int("1Antiaim.desync_range", a2-d2)
            menu.set_int("2Antiaim.desync_range", a3-d3)
            menu.set_int("3Antiaim.desync_range", a4-d4)
            cheker = true
        else
            menu.set_int("0Antiaim.desync_range", a1)
            menu.set_int("1Antiaim.desync_range", a2)
            menu.set_int("2Antiaim.desync_range", a3)
            menu.set_int("3Antiaim.desync_range", a4)
            cheker = false
        end
    end
end

client.add_callback("on_createmove", createnoise)

menu.add_check_box("Enable crosshair")

local function ForceCrosshair()

    if menu.get_bool("Enable crosshair") then

        local local_player = entitylist.get_local_player()
        local is_scoped = local_player:is_scoped()

        console.set_string("weapon_debug_spread_show", "3")

        if is_scoped == true then

            console.set_string("weapon_debug_spread_show", "0")

        else

            console.set_string("weapon_debug_spread_show", "3")

        end

    else

        console.set_string("weapon_debug_spread_show", "0")

    end
end


client.add_callback("on_paint", ForceCrosshair)

local font = render.create_font("Sagta", 12, 500, false, false, false)
menu.add_color_picker("Indicators color")
menu.add_check_box("Enable keybind list")
menu.add_slider_int("Keybinds position X", 0, engine.get_screen_width())
menu.add_slider_int("Keybinds position Y", 0, engine.get_screen_height())

local types = 
{ 
    "hold", 
    "toggled" 
}

local get_state, get_mode = menu.get_key_bind_state, menu.get_key_bind_mode
local screen_x, screen_y = engine.get_screen_width(),engine.get_screen_height()
local count = 0

local function add_bind(name, bind_name, x, y)
    if get_state(bind_name) then
        render.draw_text(font, x + 1, y + 22 + (15 * count), color.new(255, 255, 255), name)     
        text_width = render.get_text_width(font, "[" .. types[get_mode(bind_name) + 1] .. "]")
      
        render.draw_text(font, x + 150 - text_width - 1, y + 22 + (15 * count), color.new(255, 255, 255), "[" .. types[get_mode(bind_name) + 1] .. "]")      
        count = count + 1    
    end
end

local function on_paint()

    if not menu.get_bool("Enable keybind list") then 
        return 
    end

    if not engine.is_in_game() then 
        return 
    end
  
    local color = menu.get_color("Indicators color")
    local pos_x = menu.get_int("Keybinds position X")
    local pos_y = menu.get_int("Keybinds position Y") 
    local keybind_size_x = 150
    local keybind_size_y = 20
  

    render.draw_rect_filled(pos_x, pos_y, keybind_size_x, keybind_size_y, color.new(0, 0, 0, 120)) 
    render.draw_text(font, pos_x + (keybind_size_x / 2 - 20), pos_y + 4, color.new(255, 255, 255), "Keybinds") 
    render.draw_rect_filled_gradient(pos_x, pos_y, keybind_size_x / 2, 2, color.new(0, 0, 0, 0), color)
    render.draw_rect_filled_gradient(pos_x + (keybind_size_x / 2), pos_y, keybind_size_x / 2, 2, color, color.new(0, 0, 0, 0))
    
    count = 0
  
    add_bind("Safe points", key_binds.body_aim, pos_x, pos_y)
    add_bind("Damage override", key_binds.damage_override, pos_x, pos_y)
    add_bind("Double tap", key_binds.double_tap, pos_x, pos_y)
    add_bind("Hide shots", key_binds.hide_shots, pos_x, pos_y)
    add_bind("Invert desync", key_binds.flip_desync, pos_x, pos_y)
    add_bind("Thirdperson", key_binds.thirdperson, pos_x, pos_y)
    add_bind("Auto peek", key_binds.automatic_peek, pos_x, pos_y)
    add_bind("Fake duck", key_binds.fakeduck, pos_x, pos_y)
    add_bind("Slow walk", key_binds.slowwalk, pos_x, pos_y)
    add_bind("Edge jump", key_binds.edge_jump, pos_x, pos_y)
end

client.add_callback("on_paint", on_paint)


--> Menu's
menu.set_bool("Misc.show_default_log", true)
client.log("catyaw.lua Loaded Good Game:)")

--> Logs Info
local function Logs(shot_info)

    --> local function's
    
    local enemy = entitylist.get_player_by_index(i)
    local local_player = entitylist.get_local_player()
    local name = shot_info.target_name
    local server_hitbox = shot_info.server_hitbox
    local client_hitbox = shot_info.client_hitbox
    local server_damage = shot_info.server_damage
    local client_damage = shot_info.client_damage
    local backtrack = shot_info.backtrack_ticks
    local hitchance = shot_info.hitchance
    local result = shot_info.result
    local safe = shot_info.safe
    --> Hit Info
    
    if result == "Hit" then

        client.log("~ Fired shot at - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        client.log("√ Hurt - [Name: " .. name .. " | Damage: " .. server_damage .. " | Hitbox: " .. server_hitbox .. "]")
        console.execute("echo [CATYAW.lua] Fired shot at - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        console.execute("echo [CATYAW.lua] Hurt - [Name: " .. name .. " | Damage: " .. server_damage .. " | Hitbox: " .. server_hitbox .. "]")
    -->  Spread Info
    elseif result == "Spread" then

        client.log("~ Fired shot at - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        client.log("× Missed shot due to spread - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        console.execute("echo [CATYAW.lua] Fired shot at - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        console.execute("echo [CATYAW.lua] Missed shot due to spread - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        console.execute("say_team × Missed shot due to spread - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Backtrack: " .. backtrack .. "]")
    -->  Resolver Info
    elseif result == "Resolver" then

        client.log("~ Fired shot at - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        client.log("× Missed shot due to resolver - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        console.execute("echo [CATYAW.lua] Fired shot at - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        console.execute("echo [CATYAW.lua] Missed shot due to resolver - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Damage: "  .. client_damage .. " | Backtrack: " .. backtrack .. "]")
        console.execute("say_team × Missed shot due to resolver - [Name: " .. name .. " | Hitchance: " .. hitchance .. " | Hitbox: " .. client_hitbox .. " | Backtrack: " .. backtrack .. "]")
    end
    end 

--> Bobm Start Planting
local function BombBeginPlant(event)

    client.log("- Bomb begin plant!")
    console.execute("echo [CATYAW.lua] Bomb begin plant!")
    console.execute("say_team - Bomb begin plant!")

end
--> Bomb Planted
local function BombPlant(event)

    client.log("- Bomb has been planted!")
    console.execute("echo [CATYAW.lua] Bomb has been planted!")
    console.execute("say_team - Bomb has been planted!")

end
--> Bobm Start Defuse
local function BombBeginDefuse(event)

    client.log("- Bomb begin defuse!")
    console.execute("echo [CATYAW.lua] Bomb begin defuse!")
    console.execute("say_team - Bomb begin defuse!")

end
--> Hostage Info
local function HostageTaken(event)

    client.log("- Hostage taken!")
    console.execute("echo [CATYAW.lua] Hostage taken!")
    console.execute("say_team - Hostage taken!")

end

--> client.callback's
client.add_callback("on_shot", Logs)

--> all events
events.register_event("bomb_planted", BombPlant)
events.register_event("bomb_beginplant", BombBeginPlant)
events.register_event("bomb_begindefuse", BombBeginDefuse)
events.register_event("hostage_follows", HostageTaken)

menu.add_check_box("Enable Pitch Zero On Lnad")

--> local function
local old_pitch = menu.get_int("2Antiaim.pitch")
local int = 0

--> Create move for Pitch On Zero
function createmove_func(cmd)
    if menu.get_bool("Enable Pitch Zero On Lnad") == false then return end
    if entitylist.get_local_player() == nil then return end

--> Flag get_local_palyer
flag = entitylist.get_local_player():get_prop_int("CBasePlayer","m_fFlags")

--> Function For flag (256 == 262)
if flag == 256 or flag == 262 then
    int = 0
end
--> Function For flag (257 == 263)
if flag == 257 or flag == 261 or flag == 263 then
    int = int + 4
end
--> Int Function (45 == 250)
if int > 45 and int < 250 then
    menu.set_int("2Antiaim.pitch", 0)
else
    menu.set_int("2Antiaim.pitch", old_pitch)
end
end
--> client.callback
client.add_callback("on_createmove", createmove_func)

--> menu.checkbox
menu.add_check_box("Custom ThirdPerson Distande")
--> menu.slider
menu.add_slider_int("Distance", 0, 300  )

--> function thirdpesron
local function thirdperson()
    if menu.get_bool("Custom ThirdPerson Distande") == false then return end
        local tpd = menu.get_int("Distance")
            menu.set_int("Misc.thirdperson_distance", tpd)
end
--> client.callback
client.add_callback("on_createmove", thirdperson)

-- ui
menu.add_check_box("Enable indicators")
menu.add_check_box("Enable arrows")
menu.next_line()
menu.add_color_picker("Color of active arrows")
menu.add_color_picker("Color of active indicators")


-- font
local font = render.create_font("Verdana", 13, 400, true, true, true) -- u can change font of indicators here
local font_arrows = render.create_font("Verdana", 30, 600, true, true, false)

-- vars
local screen_x,screen_y = engine.get_screen_width(),engine.get_screen_height()
local get_state, get_mode, s_width = menu.get_key_bind_state, menu.get_key_bind_mode, render.get_text_width
local count = 0
local distance = 12
local red_color = color.new(255,0,0) -- change it and color of inactive indicators be changed

-- main
local function GetColorFromBool(value, first_color, second_color)
    return value and first_color or second_color
end

local function middle(label, bind_name, x, y, color, font)

    local width = render.get_text_width(font, label)
   
    render.draw_text(font, x - (width / 2), y + distance + (12 * count), GetColorFromBool(get_state(bind_name), color, red_color), label)
   
    count = count + 1

end

local function on_paint()
   
    if not menu.get_bool("Enable indicators") then return end
   
    local color_arrows = menu.get_color("Color of active arrows")
    local color_ind = menu.get_color("Color of active indicators")
   
    if menu.get_bool("Enable arrows") then
   
        render.draw_text(font_arrows, screen_x/2 - 45 - (s_width(font_arrows, "<")/2), screen_y/2 - 14, GetColorFromBool(get_state(key_binds.manual_left), color_arrows, color.new(255,255,255)), "<") -- "color.new(255,255,255)" change it and color of inactive arrows be changed
        render.draw_text(font_arrows, screen_x/2 + 45 - (s_width(font_arrows, ">")/2), screen_y/2 - 14, GetColorFromBool(get_state(key_binds.manual_right), color_arrows, color.new(255,255,255)), ">")
        render.draw_text(font_arrows, screen_x/2 - (s_width(font_arrows, "˅")/2), screen_y/2 + 20, GetColorFromBool(get_state(key_binds.manual_back), color_arrows, color.new(255,255,255)), "˅")
   
        distance = 50
   
    else
   
        distance = 12
       
    end
   
    render.draw_text(font, 100, 100, color.new(255, 255, 255), tostring(menu.get_int("Antiaim.lby_type")))
    count = 0
   
    middle("SW", key_binds.slowwalk, screen_x/2, screen_y/2, color_ind, font)
    middle("FB", key_binds.body_aim, screen_x/2, screen_y/2, color_ind, font)
    middle(get_state(key_binds.flip_desync) and "RIGHT" or "LEFT", key_binds.flip_desync, screen_x/2, screen_y/2, red_color, font)
    -- u can add ur bind here
end

-- callbacks
client.add_callback("on_paint", on_paint)

-- Menu ->
menu.add_check_box("Enable watermark")
menu.next_line()
menu.add_color_picker("Watermark line 1'st color")
menu.add_color_picker("Watermark line 2'nd color")
menu.add_color_picker("Watermark bg color")
menu.add_color_picker("Watermark text color")

-- Global Variable ->
local create_font = render.create_font("Verdana", 12, 400, true, true, false)

-- Render Watermark ->
local function WaterMark()

    --Turning Off Default Watermark If It's Turned On In The Lua Or Turning It Back On ->
    if menu.get_bool("Enable watermark") then
    
        menu.set_bool("Menu.watermark", false)

    else
    
        menu.set_bool("Menu.watermark", true)

    end

    if menu.get_bool("Enable watermark") then

        --Local Variables ->
        local line_color_first = menu.get_color("Watermark line 1'st color")
        local line_color_second = menu.get_color("Watermark line 2'nd color")
        local background_color = menu.get_color("Watermark bg color")
        local text_color = menu.get_color("Watermark text color")
        local get_intervalpertick = globals.get_intervalpertick()
        local get_tickrate = math.floor(1.0 / get_intervalpertick)
        local get_ping = globals.get_ping()
        local get_user = console.get_string("name")
        local get_time = globals.get_time()
        local get_server_address = globals.get_server_address()
        local get_framerate = globals.get_framerate()
        local displayed_text

        --Displayed Text ->
        if not engine.is_connected() then

            displayed_text = (" CATYAW.lua | " .. get_user .. " | В меню | Время: " .. get_time .. " ")

        elseif get_server_address == "Unknown" then

            displayed_text = (" CATYAW.lua | " .. get_user .. " | Соеденение к серверу | Время: " .. get_time .. " ")

        else

            displayed_text = (" CATYAW.lua | " .. get_user .. " | " .. get_server_address .. " | Пинг: " .. get_ping .. " |   Время: " .. get_time .. " ")

        end

        --Local Variables ->
        local get_screen_width = engine.get_screen_width()
        local get_text_width = render.get_text_width(create_font, displayed_text)
        local watermark_width = get_text_width + 5
        local x = get_screen_width - 10 - get_text_width - 5
        local y = 8

        --Render ->
        render.draw_rect_filled(x, y + 2, watermark_width, 18, background_color)
        render.draw_text(create_font, x + 2, y + 4, text_color, displayed_text)
        render.draw_rect_filled_gradient(x, y + 1, watermark_width, 1, line_color_first, line_color_second, 0)

    end
end

--Callback ->
client.add_callback("on_paint", WaterMark)

local function randomfakelag()
if menu.get_bool("Lag Peek") then     
menu.set_int("Antiaim.fake_lag_type", math.random(3,16))
menu.set_int("Antiaim.fake_lag_limit", math.random(5,16))
end
 end

client.add_callback("on_createmove",randomfakelag)

menu.add_check_box("Enable Chat Spam")
local phrases = { "CATYAW.lua - just the best", "CATYAW.lua - buy or die", "CATYAW - just the best", "CATYAW - better than luck" }
local nextuse = 0
local idx = 1

local function on_paint()
    
    if globals.get_curtime() > nextuse then
        if menu.get_bool("Enable Chat Spam") then
        console.execute("say \"" .. phrases[idx % #phrases + 1] .. "\"")
        idx = idx + 1
        nextuse = globals.get_curtime() + 1
    end
    end
end
client.add_callback("on_paint", on_paint)

local shot_data = {}
local switch = 1

function on_paint()

    local font = render.create_font("Verdana", 10, 400, true, false, false)
    
    for i = 1, #shot_data do
    
        local shot = shot_data[i]
        
        if shot.draw then

            if shot.alpha <= 0 then
                shot.alpha = 0
                shot.draw = false
            else
                if shot.z >= shot.target then shot.alpha = shot.alpha - 1 end
                
                local s = render.world_to_screen(vector.new(shot.x,shot.y,shot.z))

                --outline
                render.draw_text_centered(font, s.x-1, s.y, color.new(0,0,0, shot.alpha), true, true, tostring(shot.dmg))
                render.draw_text_centered(font, s.x+1, s.y, color.new(0,0,0, shot.alpha), true, true, tostring(shot.dmg))
                render.draw_text_centered(font, s.x, s.y+1, color.new(0,0,0, shot.alpha), true, true, tostring(shot.dmg))
                render.draw_text_centered(font, s.x, s.y-1, color.new(0,0,0, shot.alpha), true, true, tostring(shot.dmg))
                --end
                
                render.draw_text_centered(font, s.x, s.y, color.new(255,255,255, shot.alpha), true, true, tostring(shot.dmg))
                shot.z = shot.z + 0.5
                
            end
        end
    end
end

function player_hurt(e)

    local attacker = e:get_int("attacker")
    local attacker_idx = engine.get_player_for_user_id(attacker)
    
    local victim = e:get_int("userid")
    local victim_idx = engine.get_player_for_user_id(victim)
    
    if attacker_idx ~= engine.get_local_player_index() then
        return
    end
    
    local pos = entitylist.get_player_by_index(victim_idx):get_origin()
    local duck = entitylist.get_player_by_index(victim_idx):get_prop_float("CBasePlayer", "m_flDuckAmount")
    
    pos.z = pos.z + (46 + (1 - duck) * 18)
    
    switch = switch*-1
    
    shot_data[#shot_data+1] = { x = pos.x, y = pos.y+switch*35, z = pos.z, target = pos.z + 25, dmg = e:get_int("dmg_health"), alpha = 255, draw = true,}
end

function round_start()
    shot_data = {}
end
events.register_event("player_hurt", player_hurt)
events.register_event("round_prestart", round_start)
client.add_callback("on_paint", on_paint)


--> Menu
menu.add_check_box("Enable viewmodel is scope")
--> Function Start work
local function wievinsocpe()
    if menu.get_bool( "Enable viewmodel is scope" ) then
        console.set_int("fov_cs_debug", 90)
    else
        console.set_int("fov_cs_debug", 0)
    end
end
--> client.callback
client.add_callback( "on_paint" , wievinsocpe)

menu.add_check_box("Enable shot list")
menu.add_slider_int("Height", 1, 16)
menu.add_slider_int("Shot list position X", 0, engine.get_screen_width())
menu.add_slider_int("Shot list position Y", 0, engine.get_screen_height())

local id = 0
local font = render.create_font("Smallest Pixel-7", 11, 100, true, true, true)

local aim_table =
{

}

local function shot(shot_info)
    for i = menu.get_int("Height"), 2, -1 do
        aim_table[i] = aim_table[i-1]
    end

    local damage = shot_info.server_damage

    if damage == 0 then
        damage = "-"
    end

    local backtrack = shot_info.backtrack_ticks

    if backtrack == 0 then
        backtrack = "-"
    else
        backtrack = backtrack .. " ticks"
    end

    local hitbox = shot_info.server_hitbox

    if hitbox == "None" then
        hitbox = "-"
    end

    local result = shot_info.result

    if result == "Hit" then
        result = "-"
    else
        hitbox = shot_info.client_hitbox
    end

    id = id + 1;

    aim_table[1] =
    {
        ["id"] = id,
        ["player"] = string.sub(shot_info.target_name, 0, 10),
        ["dmg"] = damage,
        ["bt"] = backtrack,
        ["box"] = hitbox,
        ["rs"] = result
    }
end

local function draw_table(count, x, y, data)
    if data then
        local y = y + 4
        local pitch = x + 10
        local yaw = y + 15 + count * 16
        local r, g, b = 0, 0, 0
   
        if data.rs == "-" then
            r, g, b = 94, 230, 75
        elseif data.rs == "Resolver" then
            r, g, b = 245, 127, 23
        else
            r, g, b = 118, 171, 255
        end

        render.draw_rect_filled(x, yaw, 2, 15, color.new(r, g, b, 255))
        render.draw_text(font, pitch - 3, yaw + 1, color.new(255, 255, 255, 255), tostring(data.id))
        render.draw_text(font, pitch + 33, yaw + 1, color.new(255, 255, 255, 255), tostring(data.player))
        render.draw_text(font, pitch + 94, yaw + 1, color.new(0, 255, 0, 255), tostring(data.dmg))
        render.draw_text(font, pitch + 143, yaw + 1,color.new(255, 255, 255, 255), tostring(data.box))
        render.draw_text(font, pitch + 209, yaw + 1, color.new(255, 255, 255, 255), tostring(data.bt))
        render.draw_text(font, pitch + 282, yaw + 1, color.new(209, 228, 34, 255), tostring(data.rs))

        return count + 1
    end
end

local function paint()
    if menu.get_bool("Enable shot list") then  
        local x, y, d = menu.get_int("Shot list position X"), menu.get_int("Shot list position Y"), 0
        local n = menu.get_int("Height")
        local col_sz = 23 + 16 * (#aim_table > n and n or #aim_table)

        local r = math.floor(math.sin(globals.get_realtime() * 2) * 127 + 128)
        local g =  math.floor(math.sin(globals.get_realtime() * 2 + 2) * 127 + 128)
        local b = math.floor(math.sin(globals.get_realtime() * 2 + 4) * 127 + 128)

        if id > 0 then
            render.draw_rect_filled(x, y, 340, col_sz, color.new(22, 20, 26, 100))
        else
            render.draw_rect_filled(x, y, 340, 15, color.new(22, 20, 26, 100))
        end

        render.draw_rect_filled(x, y, 340, 15, color.new(16, 22, 29, 160))
        render.draw_rect_filled(x, y, 340, 2, color.new(r, g, b, 160))
        render.draw_text(font, x + 7, y + 3, color.new(255, 255, 255, 255), "ID")
        render.draw_text(font, x + 43, y + 3, color.new(255, 255, 255, 255), "PLAYER")
        render.draw_text(font, x + 104, y + 3, color.new(255, 255, 255, 255), "DMG")
        render.draw_text(font, x + 153, y + 3, color.new(255, 255, 255, 255), "HITBOX")
        render.draw_text(font, x + 219, y + 3, color.new(255, 255, 255, 255), "BACKTRACK")
        render.draw_text(font, x + 292, y + 3, color.new(255, 255, 255, 255), "REASON")

        for i = 1, menu.get_int("Height"), 1 do
            d = draw_table(d, x, y, aim_table[i])
        end
    end
end

client.add_callback("on_shot", shot)
client.add_callback("on_paint", paint)

menu.add_check_box("Enable hand changer")
menu.add_combo_box("Hand types", { "Default", "Black", "Brown", "Asian", "Red", "Tattoo" })

local function HandChanger()

    if menu.get_bool("Enable hand changer") then

        if menu.get_int("Hand types") == 0 then
            
            console.set_int("r_skin", 0)

        end

        if menu.get_int("Hand types") == 1 then
            
            console.set_int("r_skin", 1)

        end

        if menu.get_int("Hand types") == 2 then
            
            console.set_int("r_skin", 2)

        end

        if menu.get_int("Hand types") == 3 then
            
            console.set_int("r_skin", 3)

        end

        if menu.get_int("Hand types") == 4 then
            
            console.set_int("r_skin", 4)

        end

        if menu.get_int("Hand types") == 5 then
            
            console.set_int("r_skin", 5)

        end

    end
end

client.add_callback("on_paint", HandChanger)